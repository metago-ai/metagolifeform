<#
.SYNOPSIS
    MetaGO MCP Server 配置脚本（V36.8.8 - 转发到 cli.js）

.DESCRIPTION
    此脚本已统一到 node cli.js setup-mcp 实现，修复了旧版路径解析 bug。
    支持所有 7 个平台的 MCP 服务器配置（metago + metago-algorithms）。

.PARAMETER Platform
    目标平台：trae / claude-code / cursor / zcode / codebuddy / qoder / codex
    默认：trae

.PARAMETER SkipBuild
    跳过 npm 全局安装步骤

.EXAMPLE
    .\scripts\setup-mcp-server.ps1
    配置 MCP 到 Trae（默认）

.EXAMPLE
    .\scripts\setup-mcp-server.ps1 -Platform claude-code
    配置 MCP 到 Claude Code
#>

[CmdletBinding()]
param(
    [ValidateSet('trae','claude-code','cursor','zcode','codebuddy','qoder','codex')]
    [string]$Platform = 'trae',

    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"

$ScriptDir = $PSScriptRoot
$CliPath = Join-Path $ScriptDir "cli.js"

if (-not (Test-Path $CliPath)) {
    Write-Host "[错误] 找不到 cli.js: $CliPath" -ForegroundColor Red
    exit 1
}

$nodeCmd = "node"
try {
    & $nodeCmd --version 2>$null | Out-Null
} catch {
    Write-Host "[错误] 未找到 Node.js，请先安装 Node.js >= 14" -ForegroundColor Red
    exit 1
}

$cliArgs = @($CliPath, "setup-mcp", "--platform", $Platform)
if ($SkipBuild) {
    $cliArgs += "--skip-build"
}

Write-Host ""
Write-Host "MetaGO MCP 配置（V36.8.8）" -ForegroundColor Cyan
Write-Host "  平台: $Platform" -ForegroundColor Gray
Write-Host ""

& $nodeCmd @cliArgs
exit $LASTEXITCODE
