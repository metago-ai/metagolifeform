// build-release-zip.cjs — 阶段 5-4/5-5：stage 发布目录 → 根级 SHA256SUMS.txt → zip
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const ROOT = 'D:/DH工作区/metagolifeform';
const STAGE = 'D:/DH工作区/_release-3694';
const TOP = 'metagolifeform-v36.9.4';
const DST = path.join(STAGE, TOP);
const ZIP = 'C:/Users/MetaGO/Desktop/元构产品安装包/产品安装包/metagolifeform-local-v36.9.4.zip';

fs.rmSync(STAGE, { recursive: true, force: true });
fs.mkdirSync(DST, { recursive: true });

const EXCLUDE_TOP = new Set(['.git', 'node_modules', '.gitee', '.github', 'packages']);
const EXCLUDE_TOP_EXTRA = new Set(['package-lock.json', 'pnpm-lock.yaml']);
const EXCLUDE_ANY_DIR = new Set(['node_modules', 'dist', '.vite', '__pycache__', '.test-metago-memory.json']);
// 允许保留的 node_modules：local-edition/portable/node_modules
function copyTree(s, d, relParts) {
  for (const e of fs.readdirSync(s, { withFileTypes: true })) {
    const sp = path.join(s, e.name), dp = path.join(d, e.name);
    const rel = relParts.concat(e.name);
    const isPortableNm = rel.join('/') === 'local-edition/portable/node_modules';
    if (e.isDirectory()) {
      if (e.name === '.git' || e.name === 'node_modules' && !isPortableNm && !rel.includes('portable')) {
        if (!(e.name === 'node_modules' && isPortableNm)) { continue; }
      }
      if (rel.join('/').startsWith('packages/')) { continue; } // 子包随 tgz 分发
      if (EXCLUDE_ANY_DIR.has(e.name) && !isPortableNm) { if (e.name !== 'node_modules' || !rel.join('/').includes('portable')) { continue; } }
      copyTree(sp, dp, rel);
    } else {
      if (EXCLUDE_TOP_EXTRA.has(e.name) && rel.length === 1) continue;
      fs.mkdirSync(path.dirname(dp), { recursive: true });
      fs.copyFileSync(sp, dp);
    }
  }
}
copyTree(ROOT, DST, []);

// 排除后可验证：统计
function listFiles(d) {
  const out = [];
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p); else out.push(p);
    }
  })(d);
  return out;
}
const files = listFiles(DST).filter(f => path.relative(DST, f).replace(/\\/g, '/') !== 'SHA256SUMS.txt').map(f => path.relative(DST, f).replace(/\\/g, '/')).sort();
const lines = files.map(f => crypto.createHash('sha256').update(fs.readFileSync(path.join(DST, f))).digest('hex') + '  ' + f);
fs.writeFileSync(path.join(DST, 'SHA256SUMS.txt'), '# MetaGO Lifeform V36.9.4 发行包哈希清单\n' + '# 校验：sha256sum -c SHA256SUMS.txt\n' + lines.join('\n') + '\n', 'utf8');
console.log('SHA256SUMS lines:', files.length);

// 自校验：sha256sum -c 全绿
const chk = execFileSync('sha256sum', ['-c', 'SHA256SUMS.txt'], { cwd: DST, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
const bad = chk.split('\n').filter(l => !l.includes(': OK'));
console.log('sha256sum -c:', bad.length === 0 ? 'ALL OK' : 'BAD:' + bad.slice(0, 5).join('; '));

fs.mkdirSync(path.dirname(ZIP), { recursive: true });
execFileSync('powershell', ['-NoProfile', '-Command', `Compress-Archive -Path '${DST}' -DestinationPath '${ZIP}' -Force`], { stdio: 'inherit' });
const st = fs.statSync(ZIP);
console.log('ZIP OK:', ZIP, (st.size / 1048576).toFixed(1) + 'MB');
