---
name: "metago-decision-eval"
description: "决策评估技能。评估决策质量和潜在风险。评估维度：逻辑完整性、证据充分性、风险可控性、替代方案、可执行性。返回0-100分及各维度评分。"
version: "1.0.0"
author: "MetaGO"
category: "商业管理"
platforms: ["cursor","claude-code","codex","trae","codebuddy","qoder","zcode","workbuddy","qclaw","ima"]
trigger:
  - "评估这个决策"
  - "决策风险分析"
  - "多维度打分"
  - "方案对比评估"
  - "决策质量检查"
---

# 决策评估（metago-decision-eval）

## 描述
评估决策质量和潜在风险。评估维度：逻辑完整性、证据充分性、风险可控性、替代方案、可执行性。返回0-100分及各维度评分。

## 触发条件
用户请求决策评估时自动激活。重大决策输出前自动触发（与决策锁协同）。

## 核心流程
1. 接收决策内容
2. 逻辑完整性评估
3. 证据充分性评估
4. 风险可控性评估
5. 替代方案分析
6. 可执行性评估
7. 输出综合评分与建议

## 输出格式
返回结构化JSON，包含：
- 总评分（0-100）
- 各维度评分
- 风险点列表
- 改进建议

## 根源文档
`元构全息智能引擎.txt`（metago-decision-eval技能定义(241-245, 454-482)）

## 与其他技能的协同
- 与 `metago-decision-lock` 协同：决策锁关卡1意图验证时调用
- 与 `metago-whatif` 协同：替代方案分析联动反事实推演
- 与 `metago-compliance` 协同：风险可控性包含合规维度
